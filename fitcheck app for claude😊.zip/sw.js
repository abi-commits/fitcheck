// This is a minimal service worker. It just makes the app work
// while loading, which is one of the boxes Android needs checked.
self.addEventListener("install", (e) => {
  self.skipWaiting();
});

self.addEventListener("activate", (e) => {
  self.clients.claim();
});

self.addEventListener("fetch", (e) => {
  // Just pass every request straight through to the network.
  e.respondWith(fetch(e.request));
});
